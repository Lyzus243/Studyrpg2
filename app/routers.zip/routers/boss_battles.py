from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import HTMLResponse
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from typing import List
from app import models, schemas, crud
from app.database import get_async_session
from app.auth_deps import get_current_user
from fastapi.templating import Jinja2Templates
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

boss_battles_router = APIRouter(prefix="", tags=["boss_battles"])
templates = Jinja2Templates(directory="templates")

async def check_user_has_groups(user: models.User, db: AsyncSession) -> bool:
    """Check if user is a member of any study group"""
    try:
        result = await db.execute(
            select(models.UserStudyGroup).where(
                models.UserStudyGroup.user_id == user.id
            )
        )
        user_groups = result.scalars().all()
        return len(user_groups) > 0
    except Exception as e:
        logger.error(f"Error checking user groups for user {user.id}: {str(e)}")
        return False

@boss_battles_router.get("/", response_class=HTMLResponse)
async def get_boss_battles_page(
    request: Request,
    db: AsyncSession = Depends(get_async_session),
    current_user: models.User = Depends(get_current_user)
):
    try:
        if not current_user:
            logger.warning("Unauthorized access attempt to boss battles page")
            raise HTTPException(status_code=401, detail="Authentication required")
        
        # Check if user is in any study groups
        has_groups = await check_user_has_groups(current_user, db)
        if not has_groups:
            logger.warning(f"User {current_user.id} attempted to access boss battles without being in a study group")
            raise HTTPException(
                status_code=403, 
                detail="Boss battles are only available to study group members. Join a study group first!"
            )
        
        battles = await crud.get_boss_battles(db, current_user.id)
        logger.info(f"Fetched {len(battles)} boss battles for user {current_user.id}")
        return templates.TemplateResponse(
            "boss_battles.html",
            {"request": request, "battles": battles, "user": current_user}
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error in get_boss_battles_page for user {current_user.id if current_user else 'unknown'}: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to fetch boss battles: {str(e)}")

@boss_battles_router.post("/", response_model=schemas.BossBattleRead)
async def create_boss_battle(
    battle: schemas.BossBattleCreate,
    db: AsyncSession = Depends(get_async_session),
    current_user: models.User = Depends(get_current_user)
):
    try:
        if not current_user:
            logger.warning("Unauthorized attempt to create boss battle")
            raise HTTPException(status_code=401, detail="Authentication required")
        
        # Check if user is in any study groups
        has_groups = await check_user_has_groups(current_user, db)
        if not has_groups:
            logger.warning(f"User {current_user.id} attempted to create boss battle without being in a study group")
            raise HTTPException(
                status_code=403, 
                detail="Boss battles are only available to study group members. Join a study group first!"
            )
        
        if battle.difficulty < 1 or battle.difficulty > 10:
            logger.warning(f"Invalid difficulty {battle.difficulty} for boss battle creation by user {current_user.id}")
            raise HTTPException(status_code=400, detail="Difficulty must be between 1 and 10")
        
        # Create battle directly
        new_battle = models.BossBattle(
            user_id=current_user.id,
            name=battle.name,
            difficulty=battle.difficulty,
            current_health=battle.max_health,
            max_health=battle.max_health,
            reward_xp=battle.reward_xp,
            reward_skill_points=battle.reward_skill_points,
            is_completed=False
        )
        
        db.add(new_battle)
        await db.commit()
        await db.refresh(new_battle)
        
        logger.info(f"Created boss battle {new_battle.id} for user {current_user.id}")
        return schemas.BossBattleRead.from_orm(new_battle)
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error in create_boss_battle for user {current_user.id}: {str(e)}")
        await db.rollback()
        raise HTTPException(status_code=500, detail=f"Failed to create boss battle: {str(e)}")

@boss_battles_router.get("/check-access", response_model=dict)
async def check_boss_battle_access(
    db: AsyncSession = Depends(get_async_session),
    current_user: models.User = Depends(get_current_user)
):
    """Check if user has access to boss battles"""
    try:
        if not current_user:
            logger.warning("Unauthorized attempt to check boss battle access")
            raise HTTPException(status_code=401, detail="Authentication required")
        
        has_groups = await check_user_has_groups(current_user, db)
        
        # Get user's groups for additional info
        result = await db.execute(
            select(models.UserStudyGroup)
            .join(models.StudyGroup)
            .where(models.UserStudyGroup.user_id == current_user.id)
        )
        user_groups = result.scalars().all()
        
        logger.info(f"Checked boss battle access for user {current_user.id}: {has_groups}")
        return {
            'has_access': has_groups,
            'group_count': len(user_groups),
            'message': 'Access granted' if has_groups else 'You must be a member of a study group to access boss battles'
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error checking boss battle access for user {current_user.id}: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to check access: {str(e)}")