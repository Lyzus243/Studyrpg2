from fastapi import APIRouter, Depends, Request, HTTPException
from fastapi.responses import HTMLResponse
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from app.database import get_async_session
from app.models import User, ShopItem, Quest, Group, BossBattle
from app.routers.auth import get_current_user
from fastapi.templating import Jinja2Templates
from pathlib import Path
import os

# Setup templates directory
BASE_DIR = Path(__file__).parent.parent.parent
TEMPLATE_DIR = BASE_DIR / "static" / "templates" / "admin"
templates = Jinja2Templates(directory=TEMPLATE_DIR)

admin_ui = APIRouter()

def require_admin(user: User):
    admin_username = os.getenv("ADMIN_USERNAME", "Lyzus")
    if user.username != admin_username:
        raise HTTPException(status_code=403, detail="Admin access only")

@admin_ui.get("/admin/login", response_class=HTMLResponse)
async def admin_login_page(request: Request):
    """Admin login page"""
    try:
        return templates.TemplateResponse("admin/login.html", {"request": request})
    except Exception as e:
        return HTMLResponse(f"""
        <!DOCTYPE html>
        <html>
        <head>
            <title>Admin Login - StudyRPG</title>
            <style>
                body {{ 
                    background: linear-gradient(135deg, #1a1a2e 0%, #1e3c72 25%, #e52d27 60%, #ffb347 85%, #6df0ff 100%);
                    font-family: Arial, sans-serif; 
                    display: flex; 
                    justify-content: center; 
                    align-items: center; 
                    height: 100vh; 
                    margin: 0; 
                    color: white;
                }}
                .login-container {{ 
                    background: rgba(30, 60, 114, 0.9); 
                    padding: 2rem; 
                    border-radius: 16px; 
                    box-shadow: 0 8px 25px rgba(0,0,0,0.3);
                    border: 2px solid rgba(255, 179, 71, 0.3);
                    min-width: 400px;
                }}
                .form-group {{ margin-bottom: 1rem; }}
                input {{ 
                    width: 100%; 
                    padding: 12px; 
                    border: 1px solid rgba(255, 179, 71, 0.4);
                    border-radius: 8px;
                    background: rgba(26, 26, 46, 0.6);
                    color: white;
                    font-size: 1rem;
                }}
                button {{ 
                    width: 100%;
                    background: linear-gradient(to right, #e52d27, #ff6b35);
                    color: white;
                    padding: 12px;
                    border: none;
                    border-radius: 8px;
                    font-weight: bold;
                    cursor: pointer;
                    transition: all 0.3s ease;
                }}
                button:hover {{ 
                    background: linear-gradient(to right, #ff4c4c, #ff8c5a);
                    transform: translateY(-2px);
                }}
                h1 {{ color: #ffb347; text-align: center; }}
                .error {{ color: #ff4c4c; text-align: center; margin-bottom: 1rem; }}
            </style>
        </head>
        <body>
            <div class="login-container">
                <h1>🐉 Admin Portal Login</h1>
                <div id="error-message" class="error" style="display: none;"></div>
                <form id="login-form">
                    <div class="form-group">
                        <input type="text" id="username" placeholder="Username (Lyzus only)" required>
                    </div>
                    <div class="form-group">
                        <input type="password" id="password" placeholder="Password" required>
                    </div>
                    <button type="submit">Login to Admin Portal</button>
                </form>
                <div style="text-align: center; margin-top: 1rem;">
                    <a href="/" style="color: #6df0ff;">← Back to StudyRPG</a>
                </div>
            </div>
            
            <script>
                document.getElementById('login-form').addEventListener('submit', async function(e) {{
                    e.preventDefault();
                    const username = document.getElementById('username').value;
                    const password = document.getElementById('password').value;
                    const errorDiv = document.getElementById('error-message');
                    
                    if (username !== 'Lyzus') {{
                        errorDiv.textContent = 'Admin access is restricted to "Lyzus" only!';
                        errorDiv.style.display = 'block';
                        return;
                    }}
                    
                    try {{
                        const response = await fetch('/admin/token', {{
                            method: 'POST',
                            headers: {{
                                'Content-Type': 'application/x-www-form-urlencoded',
                            }},
                            body: `username=${{encodeURIComponent(username)}}&password=${{encodeURIComponent(password)}}`
                        }});
                        
                        if (response.ok) {{
                            const data = await response.json();
                            localStorage.setItem('admin_token', data.access_token);
                            window.location.href = '/admin/dashboard';
                        }} else {{
                            const errorData = await response.json();
                            errorDiv.textContent = errorData.detail || 'Login failed';
                            errorDiv.style.display = 'block';
                        }}
                    }} catch (error) {{
                        errorDiv.textContent = 'Login failed. Please try again.';
                        errorDiv.style.display = 'block';
                    }}
                }});
            </script>
        </body>
        </html>
        """)

# Signup page for admin
@admin_ui.get("/admin/signup", response_class=HTMLResponse)
async def admin_signup_page(request: Request):
    """Admin signup page - restricted to Lyzus only"""
    return HTMLResponse(f"""
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Admin Signup - StudyRPG</title>
        <style>
            body {{ 
                background: linear-gradient(135deg, #1a1a2e 0%, #1e3c72 25%, #e52d27 60%, #ffb347 85%, #6df0ff 100%);
                background-size: 400% 400%;
                animation: gradientPulse 15s ease infinite;
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                display: flex; 
                justify-content: center; 
                align-items: center; 
                height: 100vh; 
                margin: 0; 
                color: white;
            }}
            @keyframes gradientPulse {{
                0% {{ background-position: 0% 50%; }}
                50% {{ background-position: 100% 50%; }}
                100% {{ background-position: 0% 50%; }}
            }}
            .signup-container {{ 
                background: rgba(30, 60, 114, 0.9); 
                padding: 2rem; 
                border-radius: 16px; 
                box-shadow: 0 8px 25px rgba(0,0,0,0.3);
                border: 2px solid rgba(255, 179, 71, 0.3);
                min-width: 400px;
                backdrop-filter: blur(5px);
            }}
            .form-group {{ margin-bottom: 1.5rem; }}
            label {{ 
                display: block; 
                margin-bottom: 0.5rem; 
                color: #ffb347; 
                font-weight: bold; 
            }}
            input {{ 
                width: 100%; 
                padding: 12px 15px; 
                border: 1px solid rgba(255, 179, 71, 0.4);
                border-radius: 8px;
                background: rgba(26, 26, 46, 0.6);
                color: white;
                font-size: 1rem;
                transition: all 0.3s ease;
                box-sizing: border-box;
            }}
            input:focus {{
                outline: none;
                border-color: #ffb347;
                box-shadow: 0 0 0 3px rgba(255, 179, 71, 0.2);
            }}
            button {{ 
                width: 100%;
                background: linear-gradient(to right, #e52d27, #ff6b35);
                color: white;
                padding: 12px;
                border: none;
                border-radius: 8px;
                font-weight: bold;
                cursor: pointer;
                transition: all 0.3s ease;
                font-size: 1rem;
            }}
            button:hover {{ 
                background: linear-gradient(to right, #ff4c4c, #ff8c5a);
                transform: translateY(-2px);
                box-shadow: 0 5px 15px rgba(229, 45, 39, 0.3);
            }}
            h1 {{ 
                color: #ffb347; 
                text-align: center; 
                margin-bottom: 1.5rem;
                font-size: 2rem;
                text-shadow: 0 0 10px rgba(229, 45, 39, 0.5);
            }}
            .error {{ 
                color: #ff4c4c; 
                text-align: center; 
                margin-bottom: 1rem; 
                background: rgba(229, 45, 39, 0.1);
                padding: 10px;
                border-radius: 5px;
            }}
            .success {{
                color: #6df0ff;
                text-align: center;
                margin-bottom: 1rem;
                background: rgba(109, 240, 255, 0.1);
                padding: 10px;
                border-radius: 5px;
            }}
            .warning {{
                background: rgba(255, 179, 71, 0.1);
                border: 1px solid rgba(255, 179, 71, 0.3);
                color: #ffb347;
                padding: 15px;
                border-radius: 8px;
                margin-bottom: 1.5rem;
                text-align: center;
            }}
            .links {{
                text-align: center;
                margin-top: 1.5rem;
            }}
            .links a {{
                color: #6df0ff;
                text-decoration: none;
                margin: 0 10px;
            }}
            .links a:hover {{
                text-decoration: underline;
            }}
        </style>
    </head>
    <body>
        <div class="signup-container">
            <h1>🐉 Admin Registration</h1>
            
            <div class="warning">
                <strong>⚠️ Admin Access Restricted</strong><br>
                Only the username "Lyzus" is authorized for admin registration.
            </div>
            
            <div id="message" style="display: none;"></div>
            
            <form id="signup-form">
                <div class="form-group">
                    <label for="username">Username</label>
                    <input type="text" id="username" name="username" placeholder="Enter 'Lyzus' only" required>
                </div>
                
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" id="email" name="email" placeholder="Admin email address" required>
                </div>
                
                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" placeholder="Strong password" required>
                </div>
                
                <div class="form-group">
                    <label for="confirm_password">Confirm Password</label>
                    <input type="password" id="confirm_password" name="confirm_password" placeholder="Confirm password" required>
                </div>
                
                <button type="submit">Create Admin Account</button>
            </form>
            
            <div class="links">
                <a href="/admin/login">← Already have an account? Login</a> |
                <a href="/">← Back to StudyRPG</a>
            </div>
        </div>
        
        <script>
            document.getElementById('signup-form').addEventListener('submit', async function(e) {{
                e.preventDefault();
                
                const username = document.getElementById('username').value;
                const email = document.getElementById('email').value;
                const password = document.getElementById('password').value;
                const confirmPassword = document.getElementById('confirm_password').value;
                const messageDiv = document.getElementById('message');
                
                // Reset message
                messageDiv.style.display = 'none';
                messageDiv.className = '';
                
                // Validate username
                if (username !== 'Lyzus') {{
                    messageDiv.className = 'error';
                    messageDiv.textContent = 'Admin registration is restricted to username "Lyzus" only!';
                    messageDiv.style.display = 'block';
                    return;
                }}
                
                // Validate password match
                if (password !== confirmPassword) {{
                    messageDiv.className = 'error';
                    messageDiv.textContent = 'Passwords do not match!';
                    messageDiv.style.display = 'block';
                    return;
                }}
                
                // Validate password strength
                if (password.length < 6) {{
                    messageDiv.className = 'error';
                    messageDiv.textContent = 'Password must be at least 6 characters long!';
                    messageDiv.style.display = 'block';
                    return;
                }}
                
                try {{
                    const response = await fetch('/auth/signup', {{
                        method: 'POST',
                        headers: {{
                            'Content-Type': 'application/json',
                        }},
                        body: JSON.stringify({{
                            username: username,
                            email: email,
                            password: password,
                            role: 'admin'
                        }})
                    }});
                    
                    if (response.ok) {{
                        messageDiv.className = 'success';
                        messageDiv.textContent = 'Admin account created successfully! Redirecting to login...';
                        messageDiv.style.display = 'block';
                        
                        setTimeout(() => {{
                            window.location.href = '/admin/login';
                        }}, 2000);
                    }} else {{
                        const errorData = await response.json();
                        messageDiv.className = 'error';
                        messageDiv.textContent = errorData.detail || 'Registration failed';
                        messageDiv.style.display = 'block';
                    }}
                }} catch (error) {{
                    messageDiv.className = 'error';
                    messageDiv.textContent = 'Registration failed. Please try again.';
                    messageDiv.style.display = 'block';
                }}
            }});
        </script>
    </body>
    </html>
    """)

@admin_ui.get("/admin/dashboard", response_class=HTMLResponse)
async def admin_dashboard(
    request: Request, 
    db: AsyncSession = Depends(get_async_session), 
    current_user: User = Depends(get_current_user)
):
    require_admin(current_user)
    try:
        return templates.TemplateResponse("admin/dashboard.html", {
            "request": request, 
            "user": current_user
        })
    except Exception as e:
        # Return the base admin HTML directly if template not found
        with open("base_admin.html", "r") as f:
            admin_html = f.read()
        return HTMLResponse(admin_html)

# ... other existing routes ...

@admin_ui.get("/admin/boss-battles", response_class=HTMLResponse)
async def admin_boss_battles_page(
    request: Request, 
    db: AsyncSession = Depends(get_async_session), 
    current_user: User = Depends(get_current_user)
):
    require_admin(current_user)
    boss_result = await db.execute(select(BossBattle))
    boss_battles = boss_result.scalars().all()
    
    try:
        return templates.TemplateResponse("admin/boss-battles.html", {
            "request": request, 
            "boss_battles": boss_battles,
            "user": current_user
        })
    except:
        return HTMLResponse(f"""
        <div class="admin-section">
            <h3>Boss Battles ({len(boss_battles)})</h3>
            <table>
                <thead>
                    <tr><th>Name</th><th>Health</th><th>Status</th><th>Difficulty</th><th>Actions</th></tr>
                </thead>
                <tbody>
                    {"".join([f"<tr><td>{boss.name}</td><td>{boss.health}</td><td>{'Active' if getattr(boss, 'is_active', False) else 'Inactive'}</td><td>{getattr(boss, 'difficulty', 'Normal')}</td><td>Edit | Activate | Delete</td></tr>" for boss in boss_battles])}
                </tbody>
            </table>
        </div>
        """)